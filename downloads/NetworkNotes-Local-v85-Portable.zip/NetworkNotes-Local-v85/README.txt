NetworkNotes Local v85

Folder layout:
  app/   application code
  data/  your local database, notes, media, sync settings and backups

Updating/replacing app/ does not replace data/.
Local use does not require a Local account. Web authentication is requested only when using Web sync/share features.
