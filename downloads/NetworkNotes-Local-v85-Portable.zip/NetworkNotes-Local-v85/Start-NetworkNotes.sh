#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT/data"
if command -v python3 >/dev/null 2>&1; then
  exec python3 "$ROOT/app/app.py" --local
fi
echo "Python 3.10+ is required." >&2
exit 1
