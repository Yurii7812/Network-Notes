@echo off
cd /d "%~dp0"
if not exist data mkdir data
py -3 app\app.py --local
if errorlevel 1 python app\app.py --local
